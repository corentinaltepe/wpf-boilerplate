﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace $safeprojectname$
{
    [TestClass]
    public class MainViewModelTest : TestBase
    {
        [TestMethod]
        public void Constructor_Pass_Test()
        {
        }

        [TestMethod]
        public void Constructor_Fail_Test()
        {
            Assert.Fail();
        }
    }
}
